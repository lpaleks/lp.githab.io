### Tasks

- Intro
  * [Welcome Aboard!](https://github.com/rolling-scopes-school/tasks/blob/2017-Q1/tasks/welcome-aboard.md)
  * [Critical rendering path](https://github.com/rolling-scopes-school/tasks/blob/master/tasks/critical-rendering-path.md)
  * [Doubly Linked List](https://github.com/rolling-scopes-school/tasks/blob/2017-Q1/tasks/doubly-linked-list.md)
