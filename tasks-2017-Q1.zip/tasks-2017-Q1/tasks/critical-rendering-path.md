| Deadline | Folder name |
|----------|-------------|
| 16.11.2015| сritical-rendering-path |

### Critical rendering path

1. Пройти краткий онлайн курс - [Website Performance Optimization](https://www.udacity.com/course/website-performance-optimization--ud884)
2. Форкнуть репозиторий https://github.com/udacity/frontend-nanodegree-mobile-portfolio
3. Не удаляю инфу о Cameron Pittman добавить информацию (с фоткой) о себе.
4. Иcправить проблемы с временем загрузки.
5. Залить все в бранч gh-pages.
6. Протестировать полученную GitHub Page в Google PageSpeed Insights, рейтинг скорости загрузки мобильной версии это и есть ваша оценка.
7. В папку залить только файл readme.md в следующем формате:  
    - Ссылка на gh-pages бранч вашего форка  
    - Ccылка на github.io вашего gh-pages бранча
    - Ссылка на Google Page Speed Insight вида https://developers.google.com/speed/pagespeed/insights/?url=http%3A%2F%2Fwww.onliner.by%2F
    
    #####Пример итогового файла readme.md файла
    ```
    https://github.com/dzmitry-varabei/frontend-nanodegree-mobile-portfolio/tree/gh-pages
    http://dzmitry-varabei.github.io/frontend-nanodegree-mobile-portfolio/index.html
    https://developers.google.com/speed/pagespeed/insights/?url=http%3A%2F%2Fdzmitry-varabei.github.io%2Ffrontend-nanodegree-mobile-portfolio%2Findex.html&tab=mobile
    Можете добавить сюда ваши  заметки или комментарии
    ```
    
    
