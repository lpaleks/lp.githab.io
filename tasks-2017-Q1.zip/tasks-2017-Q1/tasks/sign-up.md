### Sign up to RS School

1. Убедитесь, что в вашем github профиле указана почта к которой имеете доступ (https://github.com/settings/profile)
2. Зарегестрируйтесь на [codewars](http://www.codewars.com/)
3. Заполните эту форму https://goo.gl/YPtWji
4. Ждите приглашения в rolling-scopes-school организацию (придет на почту привязаную к github-у)
5. Через некоторое время После подтверждения приглашения будет создан ваш репозиторий
  * склоньте его (`git clone https://github.com/rolling-scopes-school/<your-name>`)
  * создайте новый бранч `about-me`
  * обновите `README.md`, укажите в нем свое имя и фамилию, универ, год окончания и любую доп. информацию на ваше усмотрение
    * закомитайте обновленный `README.md`
    * push в ветку `about-me`
    * сделайте pull request из ветки `about-me` в `master` ([как?](https://help.github.com/articles/using-pull-requests/))
