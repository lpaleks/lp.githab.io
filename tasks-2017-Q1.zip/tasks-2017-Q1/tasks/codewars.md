﻿Deadline         |  Coefficient
-----------------|----------------
26.11.2016 23:59  | 0.6

Codewars 
  - Part I 
     1. http://www.codewars.com/kata/opposite-number
     2. http://www.codewars.com/kata/basic-mathematical-operations
     3. http://www.codewars.com/kata/printing-array-elements-with-comma-delimiters
     4. ttp://www.codewars.com/kata/transportation-on-vacation
     5. http://www.codewars.com/kata/calculating-with-functions
     6. http://www.codewars.com/kata/get-the-middle-character
     7. http://www.codewars.com/kata/partition-on
     8. http://www.codewars.com/kata/word-count
     9. http://www.codewars.com/kata/remove-first-and-last-character-part-two
     10. http://www.codewars.com/kata/implement-a-filter-function
     11. http://www.codewars.com/kata/prefill-an-array
     12. http://www.codewars.com/kata/cross-product-of-vectors
     13. http://www.codewars.com/kata/sequence-generator-1
  - Part II 
     1. http://www.codewars.com/kata/closures-and-scopes
     2/ http://www.codewars.com/kata/a-function-within-a-function
     3. http://www.codewars.com/kata/can-you-keep-a-secret
     4. http://www.codewars.com/kata/using-closures-to-share-class-state
     5. http://www.codewars.com/kata/a-chain-adding-function
     6. http://www.codewars.com/kata/function-cache
     7. http://www.codewars.com/kata/function-composition
     8. http://www.codewars.com/kata/function-composition-1
     9. http://www.codewars.com/kata/stringing-me-along
     10. http://www.codewars.com/kata/i-spy
  - Part III 
     1. http://www.codewars.com/kata/santaclausable-interface
     2. http://www.codewars.com/kata/new-with-apply
     3. http://www.codewars.com/kata/extract-nested-object-reference
     4. http://www.codewars.com/kata/array-helpers
     5. http://www.codewars.com/kata/replicate-new
     6. http://www.codewars.com/kata/sum-of-digits-slash-digital-root/
     7. http://www.codewars.com/kata/fun-with-es6-classes-number-2-animals-and-inheritance
     8. http://www.codewars.com/kata/fun-with-es6-classes-number-3-cuboids-cubes-and-getters
  - __Optional__
     - http://www.codewars.com/kata/lazy-evaluation
     - http://www.codewars.com/kata/tail-recursion-with-trampoline
     - http://www.codewars.com/kata/functional-sql
     - http://www.codewars.com/kata/can-you-get-the-loop
