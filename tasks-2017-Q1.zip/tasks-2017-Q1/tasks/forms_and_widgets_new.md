Deadline         | Folder Name       | Coefficient
-----------------|-------------------|---------------
27.10.2015 23:59 | forms_and_widgets | 1


Верстка стилизованных форм

Требования:

1) Pixel perfect

2) IE10+

3) Семантичность (смотрим статьи про верстку форм http://xiper.net/learn/tegofenshuj/semantic-html-forms)

4) Использование CSS sprite 

5) Календарик табличкой

6) Кнопки/элементы формы по максимуму должны иметь объединенные стили в CSS 

7) не использовать JS и препроцессоры

8) верстка слайдера

9) hover state на ссылки и кнопки


Вот очень интересная и полезная
 информация про формы.
http://habrahabr.ru/post/31279/


ссылка на макет
https://dl.dropboxusercontent.com/u/65879610/forms_widgets.psd

