﻿Deadline         | Folder Name    | Coefficient
-----------------|----------------|--------------
18.10.2016 23:59 | css-recipes    | 0.5

Ссылка на макет:

https://www.dropbox.com/sh/b1kiqkpadgwup8a/AAAU1kQWCt5yD32MGfILVSQoa?dl=0&preview=CV+Portfoilio.psd

Требования:

1.Поддержка последней версии Chrome и  FF, IE11.

2.Footer прижат к низу.

3.Колонки одинаковой высоты.

4.Шрифты взять здесь:

https://www.google.com/fonts/specimen/Montserrat

https://www.google.com/fonts/specimen/Open+Sans

Можно использовать шрифты (например, Font Awesome) для иконок.

Не допускается верстать каркас (layout) страницы табличной версткой (устаревший вариант), flexbox’ами (будет в следующих лекциях), а также с помощью CSS Grid.

При добавлении/удалении какого-нибудь компонента, страница не должна развалиться

Продумать самостоятельно hover стили


Дополнительно:
Картинки для контента  на страницу можно поместить по желанию.

http://www.lipsum.com/ - для заполнения страницы текстом

![alt tag](http://memesmix.net/media/created/09516c.jpg)
