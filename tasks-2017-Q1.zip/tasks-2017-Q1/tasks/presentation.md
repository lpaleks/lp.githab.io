| Deadline  | Folder name |
|-----------|-------------|
| 23:59 03.11.2016 | presentation |

### Presentation

Your task is to prepare a presentation on a given topic.

Requirements:
* 5 - 10 min
* Talk rehearsal within your group is mandatory
* Speaker notes for each slide is mandatory
* Language - English.

Please, upload your presentation (or a doc with a link to your slides) to the shared folder https://drive.google.com/drive/folders/0B3UA7wlxcI_-VFhrNHlkZDRJNE0.

Useful links:
* http://speaking.io/ 
* https://zachholman.com/talk/the-talk-on-talks/

