1. Create [github](https://github.com/) account
2. Join our gitter chat
  https://gitter.im/rolling-scopes-school/padawans
3. Install the following software on your machine
  * http://nodejs.org/
  * http://git-scm.com/downloads
  * http://www.sublimetext.com/
  * (optional) https://www.jetbrains.com/webstorm/
4. Learn Git basics
  * https://www.codeschool.com/courses/try-git
  * https://www.codeschool.com/courses/git-real (at least first level)
  * (optional) http://git-scm.com/book
  * (optional) https://www.udacity.com/course/ud775
  * .gitignore best practices
