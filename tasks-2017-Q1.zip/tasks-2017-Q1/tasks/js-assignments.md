﻿Deadline         | Folder Name    | Coefficient
-----------------|----------------|---------------
29.11.2016 23:59 | js_assignments     | 0.8

1. Download tasks and tests sources:  https://github.com/rolling-scopes-school/js-assignments
2. Solve as many tasks as possible :)
