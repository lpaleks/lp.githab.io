# Codecademy HTML Basics Course

1. Create profile on https://www.codecademy.com/learn
2. Go to www.codecademy.com/courses/web-beginner-en-HZA3b/0/1?curriculum_id=50579fb998b470000202dc8b and start doing tasks. Quizes are not necessary.
3. Complete first 5 units, including HTML Basics I, II, III, CSS: An Overview, CSS Selectors.
4. Badges for completion will be the proof of your work.
5. When it's done, create a branch with name HTML_CSS_Basics. There create folder HTML_CSS_Basics, and file inside (.md or .txt) where put a link to your profile. Assign pull request to your group curator.

Example:
Siarhei Shaliapin
https://www.codecademy.com/ra_Levis

Deadline         | Coefficient
-----------------|------------------
11.10.2016 23:59 | 0.2
