Deadline         | Folder Name    | Coefficient
-----------------|----------------|---------------
30.10.2016 23:59 | rwd            | 0.9

Сверстать респонсив макет.

1. Семантическая верстка соответствии с макетом (https://www.dropbox.com/s/16y4wx59p7zperz/rwd_task.psd)
2. Использовать Flexbox
3. Определить Media Queries Brakepoints (4-6 штук)
4. Определить 2 переломные точки для изменения раскладки(layout)
5. Изменять картинки на переломных Media Queries (image content issue)
6. Подключить Icon Font для иконок
7. Применить Off-Canvas технику

Ссылки на макет:
- https://www.dropbox.com/s/16y4wx59p7zperz/rwd_task.psd